import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claimsdetails',
  templateUrl: './claimsdetails.component.html',
  styleUrls: ['./claimsdetails.component.css']
})
export class ClaimsdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
