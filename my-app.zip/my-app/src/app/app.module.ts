import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import {FormsModule} from '@angular/forms';
import { ClaimsdetailsComponent } from './claimsdetails/claimsdetails.component';
import { RouterModule, Routes } from '@angular/router';
import { MenuNavComponent } from './menu-nav/menu-nav.component';
// import {MatStepperModule} from '@angular/material/stepper';

let routes:Routes =[
  {
    path: ''  ,  //default
    component: LoginComponent
  },
  {
    path: 'claimsdetails'  ,  //default
    component: ClaimsdetailsComponent
  }
]


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    ClaimsdetailsComponent,
    MenuNavComponent,
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes),
    AppRoutingModule,
    // MatStepperModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
