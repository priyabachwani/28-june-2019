import { Component } from '@angular/core';
// import { Subject } from 'rxjs-compat/Subject';
// import { Observable } from 'rxjs/Observable'
import { FormGroup } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  myform:FormGroup;
      username:string ;
      password:string;
 
constructor(private routes:Router){}

      onSubmit(formdata){
        this.username=formdata.uname;
        // console.log(this.username)
        this.password=formdata.pass;

        if(this.username==="admin" && this.password=="admin")
        {
this.routes.navigate(['/claimsdetails'])
        }
        else{
          alert("Error")
        }
      }
}