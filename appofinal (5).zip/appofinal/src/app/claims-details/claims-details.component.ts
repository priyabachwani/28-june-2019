import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claims-details',
  templateUrl: './claims-details.component.html',
  styleUrls: ['./claims-details.component.css']
})
export class ClaimsDetailsComponent implements OnInit {
  // public show:boolean = false;

  title = 'AngularMaterialGettingStarted';

  isMenuOpen = true;
  contentMargin = 240;

  task: string[] = [
    'Clearning out my closet', 'Take out trash bins', 'Wash car', 'Tank up the motorcycles', 'Go for flight training'
  ]

  constructor() { }

  ngOnInit() {
  }
  closeNav() {
document.getElementById("coll").style.width = "10px";
document.getElementById("page-content-wrapper").style.marginLeft= "0";
}

  onToolbarMenuToggle() {
    console.log('On toolbar toggled', this.isMenuOpen);
    this.isMenuOpen = !this.isMenuOpen;

    if(!this.isMenuOpen) {
      this.contentMargin = 70;
      document.getElementById("toolbarMenu").innerHTML=`<i class="fas fa-arrow-alt-circle-right fa-2x"></i>`;
    } else {
      this.contentMargin = 240;
      document.getElementById("toolbarMenu").innerHTML=`<i class="fas fa-arrow-alt-circle-left fa-2x"></i>`;
    }
  }

}

