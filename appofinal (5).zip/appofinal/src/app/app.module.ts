import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ClaimsDetailsComponent } from './claims-details/claims-details.component';
import { LoginComponent } from './login/login.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { MatInputModule, MatButtonModule, MatCardModule} from '@angular/material';
import { ToastrModule } from 'ngx-toastr';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {MatSidenavModule} from '@angular/material/sidenav';
import { SidenavComponent } from './sidenav/sidenav.component';
import { MaterialModule } from './material.module';
import { StepperComponent } from './stepper/stepper.component';
 import {MatStepperModule} from '@angular/material/stepper';
 import { MatMomentDateModule } from '@angular/material-moment-adapter'
import { UploadimgComponent } from './uploadimg/uploadimg.component';
import {MatTooltipModule} from '@angular/material/tooltip';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatIconModule} from '@angular/material/icon';
//  import moment from 'moment'

const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'claimsdetails', component: ClaimsDetailsComponent,
  children:[
    { path: 'stepper', component: StepperComponent},
    { path: 'uploadimg', component: UploadimgComponent },
  ]
},
  { path: 'sidenav', component: SidenavComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    ClaimsDetailsComponent,
    LoginComponent,
    SidenavComponent,
    StepperComponent,
    UploadimgComponent
     ],
  imports: [
    BrowserModule,
    MatSidenavModule,
    FormsModule,
    MatCardModule,
    NoopAnimationsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
     MatButtonModule,
     MatInputModule,
     MatStepperModule,
    RouterModule.forRoot(routes),
    MaterialModule,
    MatMomentDateModule,
    MatTooltipModule,
    MatFormFieldModule,
    MatFormFieldModule
    // moment,
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
