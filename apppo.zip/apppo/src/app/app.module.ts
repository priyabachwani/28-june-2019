import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ClaimsDetailsComponent } from './claims-details/claims-details.component';
import { LoginComponent } from './login/login.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
// import {MatStepperModule, MatInputModule, MatButtonModule} from '@angular/material';
const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'claimsdetails', component: ClaimsDetailsComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    ClaimsDetailsComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    BrowserAnimationsModule,
    // MatButtonModule,
    // MatInputModule,
    // MatStepperModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
