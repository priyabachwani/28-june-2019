import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-claims-details',
  templateUrl: './claims-details.component.html',
  styleUrls: ['./claims-details.component.css']
})
export class ClaimsDetailsComponent implements OnInit {
  public show:boolean = false;
  constructor() { }

  ngOnInit() {
  }
  closeNav() {
document.getElementById("wrapper").style.width = "0";
document.getElementById("page-content-wrapper").style.marginLeft= "0";
}
toggle() {
  this.show = !this.show;

}
}
