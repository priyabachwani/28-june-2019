import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { ClaimsDetailsComponent } from './claims-details/claims-details.component';
import { LoginComponent } from './login/login.component';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {MatStepperModule, MatInputModule, MatButtonModule, MatCardModule} from '@angular/material';
import { ToastrModule } from 'ngx-toastr';
import {NoopAnimationsModule} from '@angular/platform-browser/animations';
import {MatSidenavModule} from '@angular/material/sidenav';
import { SidenavComponent } from './sidenav/sidenav.component';
import { MaterialModule } from './material.module';
import { NewComponentComponent } from './new-component/new-component.component';



const routes: Routes = [
  { path: '', component: LoginComponent },
  { path: 'claimsdetails', component: ClaimsDetailsComponent },
  { path: 'sidenav', component: SidenavComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    ClaimsDetailsComponent,
    LoginComponent,
    SidenavComponent,
    NewComponentComponent
  ],
  imports: [
    BrowserModule,
    MatSidenavModule,
    FormsModule,
    MatCardModule,
    MaterialModule,
    NoopAnimationsModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
     MatButtonModule,
     MatInputModule,
     MatStepperModule,
    RouterModule.forRoot(routes),
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
