import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent{
public user:string;
public pass:string;

registerForm: FormGroup;

constructor(private fb: FormBuilder,private routes:Router,private toastr: ToastrService) { }

ngOnInit(): void {
    this.registerForm = this.fb.group({
        Username: [null,
          Validators.compose([
              Validators.required,
              Validators.pattern("admin")
          ])],
        Password: [null,
          Validators.compose([
              Validators.required,
              Validators.pattern("admin")
          ])]
});

}
showToaster(){
  this.toastr.success("Incorrect username and password")
}
onSubmit(formdata){
  this.user=formdata.Username;
  console.log(this.user)
  this.pass=formdata.Password;

  if(this.user==="admin" && this.pass=="admin")
  {
this.routes.navigate(['/claimsdetails'])
  }
  else{
    this.showToaster();
  }
}
  
  
}
